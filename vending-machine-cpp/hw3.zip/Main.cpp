#include <iostream>
#include <string>
#include "VendingMachine.h"

using namespace std;
//using boost::lexical_cast;

vector<string>* parse_user_command(string line){
	string delimiter = " ";
	size_t pos = 0;
	string token;
	vector<string>*vect;
	while ((pos = line.find(delimiter)) != string :: npos) {
		token = line.substr(0, pos);
		vect->push_back(token);

		line.erase(0, pos + delimiter.length());
		}
		vect->push_back(line);

		return vect;
		}

int main(){
	cout << "Hello" << endl;
	cout << "VendingMachine initialized." << endl;
	VendingMachine* vm = new VendingMachine();
	vm->printCurrentState();
	cout << "Please enter the number of q,n,d,v, and whether the cancel button is pressed (0 or 1)" << endl;
	bool notready = true;
	while(notready){
		cout << "Enter q n d v first." << endl;
		string* quarter, *nickel, *dime, *value, *cancelstring;
		bool *cancel = new bool();
		
		
		cin >> *quarter >> *nickel >> *dime >> *value;
		
		
		cout << "Now enter cancel setting. 0 or 1" << endl;
		cin >> *cancelstring;
		if(*cancelstring == "1"){
			*cancel = true;
		}
		
		int quarterint = stoi(*quarter);
		int nickelint = stoi(*nickel);
		int dimeint = stoi(*dime);
		int valueint = stoi(*value);

		int* quarterint1 = &quarterint;
		int* nickelint1 = &nickelint;
		int* dimeint1 = &dimeint;
		int* valueint1 = &valueint;
		vm->initializeVM(quarterint1, nickelint1, dimeint1, 
		valueint1, cancel);
		notready = false;
		
		
	}
	cout << "Initial state : " <<endl;
	vm->printCurrentState();
	
	
	bool run = true;
	while(run){
		cout << "enter inputs separated by a white space. " <<endl;
		cout << "Available inputs : q n d c w " << endl;
		string command; 
		cin >> command;
		vector<string>* inputs = parse_user_command(command);
		if(inputs->size()== 1 && inputs->at(0) == "quit"){
			cout << "terminated" << endl;
			delete inputs;
			run = false;
		}else if (inputs->size()==1 && inputs->at(0)=="check"){
			vm->printCurrentState();
			delete inputs;
		}else{
			bool valid = false;
			for(int i = 0; i < inputs->size(); i ++){
				string token = inputs->at(i);
				
				if(token=="q" || token == "n" || token == "d" || token == "c" 
				|| token == "w"){
					valid = true;
				}else{
					valid = false;
					break;
				}
			}
			if(valid){
				vm->produceAndPrintOutput();
				vm->stateTransition(inputs);
				
			}else{
				cout << "Input invalid. Please try again." << endl;
			}
			delete inputs;
			
			
		}
		
	}
	
	//return 0;
}
