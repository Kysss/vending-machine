#include "VMException.h"
#include <iostream>
#include <exception>

using namespace std;

void VMException :: VMException(){
}